class CoursepagesController < ApplicationController
  def new
    @course = Course.new
    #@departments = Department.all
  end

  def create

        p '--------------------------------------------------------------'

        p params

        @course = Course.new(params.require( :course ).permit( :name , :department_id ))
        #@department = Department.new(params[:name])
        if @course.save
          redirect_to :action => 'success'
        else 
          render :action => 'new'
        end

  end

  def edit
  end

  def show


    @courses= Course.all
  end

  def destroy
  end

  def delete
  end

  def find
  end

  def search
  end

  def success
  end

  def fail
  end
end
