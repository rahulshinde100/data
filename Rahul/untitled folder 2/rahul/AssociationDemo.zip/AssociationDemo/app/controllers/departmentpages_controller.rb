class DepartmentpagesController < ApplicationController
  def new
    @department = Department.new
  end

  def create

        p '--------------------------------------------------------------'

        p params

        @department = Department.new(params.require( :department).permit( :name ))
        #@department = Department.new(params[:name])
        if @department.save
          redirect_to :action => 'success'
           else 
              render :action => 'new'
        end
  end

  def edit

  end


  def show
       @departments = Department.all
  end

  def destroy

  end

  def delete

  end

  def find

  end

  def search

  end

  def success

  end

  def fail

  end
end
