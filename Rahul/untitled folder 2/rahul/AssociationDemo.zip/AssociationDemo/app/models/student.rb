class Student < ActiveRecord::Base
	belongs_to :department
	belongs_to :course

	validates_presence_of :name , :std , :department_id , :course_id
end
