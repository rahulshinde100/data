require 'test_helper'

class StudentpagesHelperTest < ActionView::TestCase
end
