require 'test_helper'

class CoursepagesHelperTest < ActionView::TestCase
end
