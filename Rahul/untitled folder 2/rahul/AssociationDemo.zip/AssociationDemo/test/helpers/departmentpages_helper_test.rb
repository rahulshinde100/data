require 'test_helper'

class DepartmentpagesHelperTest < ActionView::TestCase
end
