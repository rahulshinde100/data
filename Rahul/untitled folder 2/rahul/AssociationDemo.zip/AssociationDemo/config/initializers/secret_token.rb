# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
AssociationDemo::Application.config.secret_key_base = 'f752d12f27cc2d26158e0204f1b9651144c725483e904863c3557a5e93a93e8a312732c2e393fdf4f4f274012ba6beeb674bfcff5e8e89f6edf2718bd9f1411c'
